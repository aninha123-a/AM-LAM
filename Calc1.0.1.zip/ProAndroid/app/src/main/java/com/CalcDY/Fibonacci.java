package com.CalcDY;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Fibonacci extends AppCompatActivity {

    Button bt_calcular;

    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.fibonacci);

        bt_calcular = findViewById(R.id.calc);
        bt_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fibo();
            }
        });

    }

    public void fibo() {
        EditText termo = findViewById(R.id.valor);
        String x = termo.getText().toString();
        String str;
        if (!x.equals("")) {
            if (Integer.parseInt(x) <= 1)  {
                str = "【0】";
            }else if (Integer.parseInt(x) == 2) {
                str = "【0, 1】";
            } else {
                int p = Integer.parseInt(x);
                int[] ray;
                ray = new int[p];
                ray[0] = 0;
                ray[1] = 1;
                str = "【0, 1, ";
                for (int i = 2; i < p; i++) {
                    ray[i] = ray[i-2] + ray[i-1] ;
                    if (i < p-1) {
                        str += ray[i] + ", ";
                    }else {
                        str += ray[i] + "】";
                    }
                }
            }
            termo.setText("");
            TextView result = findViewById(R.id.result);
            result.setText(str);
        }
    }

}
