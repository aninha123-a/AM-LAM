package com.CalcDY;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Stack;

public class Pilha extends AppCompatActivity {

    Stack<Integer> stack = new Stack<Integer>();
    Button bt_empilhar;
    Button bt_desempilhar;
    Button bt_somar;
    Button bt_subtrair;
    Button bt_multiplicar;
    Button bt_dividir;
    int x, n1, n2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pilha);

        bt_empilhar = findViewById(R.id.emp);
        bt_empilhar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                empilhar();
            }
        });

        bt_desempilhar = findViewById(R.id.desemp);
        bt_desempilhar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                desempilhar();
            }
        });

        bt_somar = findViewById(R.id.soma);
        bt_somar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                somar();
            }
        });

        bt_subtrair = findViewById(R.id.sub);
        bt_subtrair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subtrair();
            }
        });

        bt_multiplicar = findViewById(R.id.mult);
        bt_multiplicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                multiplicar();
            }
        });

        bt_dividir = findViewById(R.id.div);
        bt_dividir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dividir();
            }
        });

    }

    public void empilhar() {
        EditText numb = findViewById(R.id.numero);
        String x = numb.getText().toString();
        if (!x.equals("")) {
            TextView result = findViewById(R.id.stack);
            stack.push(Integer.parseInt(x));
            numb.setText("");
            result.setText(stack + "");
        }
    }

    public void desempilhar() {
        if (!stack.empty()){
            stack.pop();
            TextView result = findViewById(R.id.stack);
            result.setText(stack + "");
        }
    }

    public void somar() {
        if (stack.size() >= 2) {
            n1 = stack.pop();
            n2 = stack.pop();
            x = n1 + n2;
            stack.push(x);
            TextView result = findViewById(R.id.stack);
            result.setText(stack + "");
        }
    }

    public void subtrair() {
        if (stack.size() >= 2) {
            n1 = stack.pop();
            n2 = stack.pop();
            x = n1 - n2;
            stack.push(x);
            TextView result = findViewById(R.id.stack);
            result.setText(stack + "");
        }
    }

    public void multiplicar() {
        if (stack.size() >= 2) {
            n1 = stack.pop();
            n2 = stack.pop();
            x = n1 * n2;
            stack.push(x);
            TextView result = findViewById(R.id.stack);
            result.setText(stack + "");
        }
    }

    public void dividir() {
        if (stack.size() >= 2){
            int zero = stack.size();
            if (stack.elementAt(zero-2) != 0 ) {
                n1 = stack.pop();
                n2 = stack.pop();
                x = n1 / n2;
                stack.push(x);
                TextView result = findViewById(R.id.stack);
                result.setText(stack + "");
            }
        }
    }

}
