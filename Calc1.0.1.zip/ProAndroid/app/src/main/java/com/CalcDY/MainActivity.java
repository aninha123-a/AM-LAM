package com.CalcDY;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.util.Stack;


public class MainActivity extends AppCompatActivity {

    Button botao_pilha;
    Button botao_fibonacci;
    Stack<Integer> stack = new Stack<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botao_pilha = findViewById(R.id.btPil);
        botao_pilha.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Pilha.class);
                startActivity(i);
            }
        });

        botao_fibonacci = findViewById(R.id.btFib);
        botao_fibonacci.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Fibonacci.class);
                startActivity(i);
            }
        });
    }

}